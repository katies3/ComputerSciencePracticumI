package com.project.comic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComicApplicationTests {

	@Test
	void contextLoads() {
	}

}
